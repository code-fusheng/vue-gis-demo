import { createApp } from "vue";
import App from "./App.vue";
import router from "./router";

import "./assets/main.css";
import ElementPlus from "element-plus";
import "element-plus/dist/index.css";

// import "ol-cesium/dist/olcesium.css";
window.CESIUM_BASE_URL = "/cesium/";

import axios from "axios";
import VueAxios from "vue-axios";

const app = createApp(App);

app.use(router);
app.use(ElementPlus);

app.use(VueAxios, axios);
app.provide("axios", app.config.globalProperties.axios);
app.config.globalProperties.$axios = axios;

app.mount("#app");
